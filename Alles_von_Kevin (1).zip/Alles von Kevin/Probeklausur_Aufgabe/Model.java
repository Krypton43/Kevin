import java.awt.*;
import java.util.List;
import java.util.NoSuchElementException;

public class Model {

    private List<Point> values;

    public List<Point> getValues() {
        return values;
    }

    public Point scalePoint(Point p, int width, int height) {
        int maxX = values
                .stream()
                .mapToInt(v -> v.x)
                .max().orElseThrow(NoSuchElementException::new);

        int maxY = values
                .stream()
                .mapToInt(v -> v.y)
                .max().orElseThrow(NoSuchElementException::new);

        return new Point(width * p.x / maxX, height * p.y / maxY);
    }
}
