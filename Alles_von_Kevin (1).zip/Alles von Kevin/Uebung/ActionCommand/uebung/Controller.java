package uebung;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

public class Controller implements ActionListener {
	
	View view;
	
	public void initialize(View view) {
		this.view = view;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();
		
		if ("Show Dialog" == cmd) {
			JOptionPane.showMessageDialog(view, "Eggs are not supposed to be green.");
			view.getBtn().setText("Don't show Dialog");
		}
	}

}
