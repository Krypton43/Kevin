package uebung;

public class Model {

}
