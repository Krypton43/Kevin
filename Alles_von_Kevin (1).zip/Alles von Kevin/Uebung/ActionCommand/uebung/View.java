package uebung;

import javax.swing.JButton;
import javax.swing.JFrame;

public class View extends JFrame {

	Controller controller;
	
	JButton btn;
		
	public void initialize(Controller controller) {
		this.controller = controller;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Test");
		
		btn = new JButton("Show Dialog");
		btn.addActionListener(controller);
		
		add(btn);
		
		pack();
		setVisible(true);		
	}

	public JButton getBtn() {
		return btn;
	}
}
