import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class Controller implements ActionListener, PropertyChangeListener {

	private Model m;
	private View v;

	public void initialize(Model m, View v) {
		this.m = m;
		this.v = v;
		
		this.m.addPropertyChangeListener(this);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		String ac = e.getActionCommand();
		
		if ("S".equals(ac)) {
			m.clear();
			m.addStartTime();
		} else if ("P".equals(ac)) {
			m.addPauseTime();
		} else if("E".equals(ac)) {
			m.addEndTime();
		}
	}

	@Override
	public void propertyChange(PropertyChangeEvent evt) {
		String propName = evt.getPropertyName();
		boolean newValue = (boolean)evt.getNewValue();
		
		if ("isInPause".equals(propName)) {
			v.getBtnEnde().setEnabled(!newValue);
		} else if ("hasStarted".equals(propName)) {
			if (newValue) {
				v.getBtnStart().setEnabled(false);
				v.getBtnPause().setEnabled(true);
				v.getBtnEnde().setEnabled(true);
			} else {
				v.getBtnStart().setEnabled(true);
				v.getBtnPause().setEnabled(false);
				v.getBtnEnde().setEnabled(false);
			}
		}
	}

}
