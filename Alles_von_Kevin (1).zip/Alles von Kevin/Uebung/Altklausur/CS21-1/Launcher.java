
public class Launcher {

	public static void main(String[] args) {
		Controller c = new Controller();
		Model m = new Model();
		View view = new View();
		
		c.initialize(m, view);
		view.initialize(m, c);
	}

}
