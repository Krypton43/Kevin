import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JToolBar;

public class View extends JFrame {

	private Model m;
	private JButton btnPause;
	private JButton btnStart;
	private JButton btnEnde;
	private Controller c;

	public void initialize(Model m, Controller c) {
		this.m = m;
		this.c = c;
		
		setTitle("Arbeitszeit");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setSize(400, 200);
		
		addComponents();
		
		setVisible(true);		
	}

	private void addComponents() {
		btnStart = new JButton("S");
		btnStart.addActionListener(c);
		
		btnPause = new JButton("P");
		btnPause.setEnabled(false);
		btnPause.addActionListener(c);
		
		btnEnde = new JButton("E");
		btnEnde.setEnabled(false);
		btnEnde.addActionListener(c);
		
		JToolBar toolbar = new JToolBar();
		toolbar.add(btnStart);
		toolbar.add(btnPause);
		toolbar.add(btnEnde);
		
		add(toolbar, BorderLayout.PAGE_START);
		
		JTable table = new JTable(m.getTableModel());
		
		add(new JScrollPane(table));
	}

	public JButton getBtnPause() {
		return btnPause;
	}

	public JButton getBtnStart() {
		return btnStart;
	}

	public JButton getBtnEnde() {
		return btnEnde;
	}
}
