import java.util.HashMap;
import java.util.Map;

public class BarCode {

	private static final int HEIGHT = 150;
	
	private static final int SIZE_WIDE = 6;
	private static final int SIZE_SLIM = 3;
	
	private static Map<Character, String> coding;
	
	static {
		coding = new HashMap<>();
		coding.put('0', "ssswwswss");
		coding.put('1', "wsswssssw");
		coding.put('2', "sswwssssw");
		coding.put('3', "wswwsssss");
		coding.put('4', "ssswwsssw");
		coding.put('5', "wsswwssss");
		coding.put('6', "sswwwssss");
		coding.put('7', "ssswsswsw");
		coding.put('8', "wsswsswss");
		coding.put('9', "sswwsswss");
		coding.put('A', "wsssswssw");
		coding.put('B', "sswsswssw");
		coding.put('C', "wswsswsss");
		coding.put('D', "sssswwssw");
		coding.put('E', "wssswwsss");
		coding.put('F', "sswswwsss");
		coding.put('G', "ssssswwsw");
		coding.put('H', "wsssswwss");
		coding.put('I', "sswsswwss");
		coding.put('J', "sssswwwss");
		coding.put('K', "wssssssww");
		coding.put('L', "sswssssww");
		coding.put('M', "wswssssws");
		coding.put('N', "sssswssww");
		coding.put('O', "wssswssws");
		coding.put('P', "sswswssws");
		coding.put('Q', "sssssswww");
		coding.put('R', "wssssswws");
		coding.put('S', "sswssswws");
		coding.put('T', "sssswswws");
		coding.put('U', "wwssssssw");
		coding.put('V', "swwsssssw");
		coding.put('W', "wwwssssss");
		coding.put('X', "swsswsssw");
		coding.put('Y', "wwsswssss");
		coding.put('Z', "swwswssss");
		coding.put('-', "swsssswsw");
		coding.put('.', "wwsssswss");
		coding.put(' ', "swwssswss");
		coding.put('*', "swsswswss");
		coding.put('$', "swswswsss");
		coding.put('/', "swswsssws");
		coding.put('+', "swssswsws");
		coding.put('%', "ssswswsws");
	}
	
	public void setCode(String code) {
		/**
			TODO
		 */
		
		revalidate();
		repaint();
	}
	
	@Override
	public int getHeight() {
		return HEIGHT;
	}
	
	@Override
	public Dimension getPreferredSize() {
		int width = /** TODO */;
		
		return new Dimension(width, getHeight());
	}
}
