import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.MethodDescriptor;
import java.beans.PropertyDescriptor;

public class Launcher {

	public static void main(String[] args) throws IntrospectionException {
		Frame f = new Frame("Barcode Example");
		f.addWindowListener(new WindowAdapter() {
		@Override
		public void windowClosing(WindowEvent e) {
			super.windowClosing(e);
				
				f.dispose();
			}
		});
		
		BeanInfo bi = Introspector.getBeanInfo(BarCode.class);
		
		for(PropertyDescriptor d : bi.getPropertyDescriptors()) {
			System.out.println(d.getName());
		}

		for(MethodDescriptor d : bi.getMethodDescriptors()) {
			System.out.println(d.getName());
		}
		
		BarCode b = new BarCode();
		b.setCode("Hallo");
		
		f.add(b);
		f.pack();
		
		f.setVisible(true);
	}

}
