public class Launcher {

	public static void main(String[] args) {
		Model model = new Model();
		Controller controller = new Controller();
		View view = new View();
		
		controller.initialize(model, view);
		view.initialize(controller, model);
	}

}
