import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.awt.List;
import java.awt.Panel;
import java.awt.TextField;

public class View extends Frame implements PropertyChangeListener {

	private static final long serialVersionUID = -8215973777232473220L;

	private Model model;
	private Controller controller;
	
	private List listStudents;
	private TextField tfStudent;
	
	public void initialize(Controller controller, Model model) {
		this.controller = controller;
		this.model = model;

		model.addPropChangeListener(this);
		
		setSize(new Dimension(400, 200));
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				super.windowClosing(e);
				
				dispose();
			}
		});
		
		addComponents();
		
		setVisible(true);
	}
	
	public void addComponents() {
		listStudents = new List();
		
		for (String sName : model.getStudents()) {
			listStudents.add(sName);
		}
		
		add(listStudents);
		
		Panel panelBottom = new Panel();
		
		tfStudent = new TextField("Student Name");
		
		Button b = new Button("Test");
		b.addActionListener(controller);
		
		panelBottom.add(tfStudent);
		panelBottom.add(b);
		
		add(panelBottom, BorderLayout.PAGE_END);
	}

	public Model getModel() {
		return model;
	}

	public void setModel(Model model) {
		this.model = model;
		
		if (model != null) {
			model.addPropChangeListener(this);
		}
	}

	public List getListStudents() {
		return listStudents;
	}

	public void setListStudents(List listStudents) {
		this.listStudents = listStudents;
	}

	public TextField getTfStudent() {
		return tfStudent;
	}

	public void setTfStudent(TextField tfStudent) {
		this.tfStudent = tfStudent;
	}

	public Controller getController() {
		return controller;
	}

	public void setController(Controller controller) {
		this.controller = controller;
	}

	@Override
	public void propertyChange(PropertyChangeEvent evt) {
		if ("students".equals(evt.getPropertyName())) {
			listStudents.removeAll();
			
			for (String sName : model.getStudents()) {
				listStudents.add(sName);
			}
		}
	}
}
