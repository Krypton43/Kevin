import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControllerProbeKlausur implements ActionListener {
	
	private ModelProbeKlausur m;
	private DiagramView v;

	public void initialize(DiagramView v, ModelProbeKlausur m) {
			this.v = v;
			this.m = m;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		int x = Integer.valueOf(v.getTfX().getText());
		int y = Integer.valueOf(v.getTfY().getText());
		m.addPoint(x, y);
	}

}
