import javax.swing.*;
import java.awt.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class DiagramView extends JFrame implements PropertyChangeListener {

    ModelProbeKlausur m;
    ControllerProbeKlausur c;
    private JTextField tfX;
    private JTextField tfY;

    public void initialize(ModelProbeKlausur m, ControllerProbeKlausur c) {
        this.m = m;
        this.c = c;

        this.m.addPropChangeLis(this);

        setTitle("Diagramm");

        setSize(new Dimension(800, 400));

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        addComponents();

        setVisible(true);
    }

    private void addComponents() {
        JPanel panelInput = new JPanel();

        JLabel lX = new JLabel("X:");
        tfX = new JTextField("0");

        JLabel lY = new JLabel("Y:");
        tfY = new JTextField("0");

        JButton btnAdd = new JButton("Hinzuf�gen");
        btnAdd.addActionListener(c);

        panelInput.add(lX);
        panelInput.add(tfX);
        panelInput.add(lY);
        panelInput.add(tfY);
        panelInput.add(btnAdd);

        add(panelInput, BorderLayout.PAGE_START);

        JDiagram d = new JDiagram();
        d.initialize(m);

        add(d);
    }

    public JTextField getTfX() {
        return tfX;
    }

    public JTextField getTfY() {
        return tfY;
    }

    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        repaint();
    }
}
