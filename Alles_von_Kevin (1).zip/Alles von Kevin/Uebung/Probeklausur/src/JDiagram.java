import javax.swing.*;
import java.awt.*;

public class JDiagram extends JComponent {

    private ModelProbeKlausur m;

    public void initialize(ModelProbeKlausur m) {
        this.m = m;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        g.drawLine(15, 20, 15, getHeight() - 15);
        g.drawLine(15, getHeight() - 15, getWidth() - 20, getHeight() - 15);

        g.fillPolygon(new int[]{10, 15, 20}, new int[]{20, 15, 20}, 3);
        g.fillPolygon(new int[]{getWidth() - 20, getWidth() -  15, getWidth() - 20}, new int[]{getHeight() - 10, getHeight() -  15, getHeight() - 20}, 3);

        for (Point p : m.getValues()) {
            p = m.scalePoint(p, getWidth() - 15 - 20, getHeight() - 15 - 20);
            g.fillRect(p.x - 2 + 15, getHeight() - p.y  - 15 - 2, 4, 4);
        }
    }
}
