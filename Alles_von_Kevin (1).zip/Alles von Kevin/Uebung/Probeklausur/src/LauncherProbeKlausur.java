public class LauncherProbeKlausur {
    public static void main(String[] args) {
        ModelProbeKlausur m = new ModelProbeKlausur();
        DiagramView v = new DiagramView();
        ControllerProbeKlausur c = new ControllerProbeKlausur();

        m.initialize(v);
        v.initialize(m, c);
        c.initialize(v, m);
    }
}
