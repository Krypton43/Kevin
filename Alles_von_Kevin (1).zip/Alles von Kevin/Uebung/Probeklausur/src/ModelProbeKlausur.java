import java.awt.*;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

public class ModelProbeKlausur {

    private DiagramView v;

    private PropertyChangeSupport pcs;

    private List<Point> values;


    public void initialize(DiagramView v) {
        this.v = v;
        this.pcs = new PropertyChangeSupport(this);

        values = new ArrayList<>();
    }

    public void addPropChangeLis(PropertyChangeListener l) {
        pcs.addPropertyChangeListener(l);
    }

    public void addPoint(int x, int y) {
        int oldSize = values.size();

        values.add(new Point(x, y));

        pcs.firePropertyChange("values", oldSize, values.size());
    }

    public List<Point> getValues() {
        return values;
    }

    public Point scalePoint(Point p, int width, int height) {
        int maxX = values
                .stream()
                .mapToInt(v -> v.x)
                .max().orElseThrow(NoSuchElementException::new);

        int maxY = values
                .stream()
                .mapToInt(v -> v.y)
                .max().orElseThrow(NoSuchElementException::new);

        return new Point(width * p.x / maxX, height * p.y / maxY);
    }
}
