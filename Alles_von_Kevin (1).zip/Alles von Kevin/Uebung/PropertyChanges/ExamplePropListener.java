import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class ExamplePropListener implements PropertyChangeListener {

	@Override
	public void propertyChange(PropertyChangeEvent evt) {
		System.out.println(evt.getNewValue());
	}
}
