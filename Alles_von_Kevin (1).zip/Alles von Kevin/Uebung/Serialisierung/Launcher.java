import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Launcher {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		/*
		Frame f = new Frame("Barcode Example");
		f.addWindowListener(new WindowAdapter() {
		@Override
		public void windowClosing(WindowEvent e) {
			super.windowClosing(e);
				
				f.dispose();
			}
		});
		
		BarCode b = new BarCode();
		b.setCode("Hallo");
		
		f.add(b);
		f.pack();
		
		f.setVisible(true);
		
		FileOutputStream fos = new FileOutputStream("test");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		oos.writeObject(f);
		
		oos.flush();
		
		oos.close();
		fos.close(); */
		
		FileInputStream fis = new FileInputStream("test");
		ObjectInputStream ois = new ObjectInputStream(fis);
		
		Frame f =  (Frame)ois.readObject();
		f.setVisible(true);
	}

}
