package uebung;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Polygon;

import javax.swing.JTextField;

public class MyJTextField extends JTextField {

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		g.setColor(Color.RED);
		
		Polygon p = new Polygon();
		p.addPoint(getWidth() - 15, 0);
		p.addPoint(getWidth(), 0);
		p.addPoint(getWidth(), getHeight() / 2);
		
		g.fillPolygon(p);
	}
	
}
