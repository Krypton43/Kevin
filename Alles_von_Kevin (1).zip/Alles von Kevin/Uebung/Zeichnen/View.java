package uebung;

import javax.swing.JFrame;

public class View extends JFrame {

	Controller controller;
	
	MyJTextField tf;
		
	public void initialize(Controller controller) {
		this.controller = controller;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Test");
		
		tf = new MyJTextField();
		
		add(tf);
		
		pack();
		setVisible(true);		
	}
	
}
